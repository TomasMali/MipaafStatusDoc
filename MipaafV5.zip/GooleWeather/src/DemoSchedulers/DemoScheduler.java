package DemoSchedulers;

import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.telegram.telegrambots.api.methods.send.SendMessage;
import org.telegram.telegrambots.api.objects.Update;
import org.telegram.telegrambots.exceptions.TelegramApiException;

import App.SianConnect;
import Jsoup.Query;

/**
 * This is a sample class to execute scheduler on specific date based on <code>java.util.Calendar</code>. Over here,
 * <code>executor</code> is a runnable which run on everyday basis from 8:00 AM to 5:00 PM.
 * 
 * @author Tomas Mali
 */
public class DemoScheduler {

	public static SianConnect mySianConnect = null;
	public static Update update = null;
	public static String query = "";
	public static boolean firstTime = true;
	public static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

	public DemoScheduler(SianConnect instance, Update update) {
		mySianConnect = instance;
		this.update = update;

	}

	public static void setQuery(String s) {
		query = s;
	}

	/**
	 * Questo metodo fa partire il thread
	 * 
	 * @throws IOException
	 */
	public static void runThreadWithTask() throws IOException {

		Runnable task = new Runnable() {

			@Override
			public void run() {

				String query = Query.copyURLToFile("https://www.sian.it/public/mipaaf/WS%20MVV-E%20vers%201.6.zip");
				System.out.println("Mon Oct 15 12:59:16 CEST 2018" + "\n" + query);

				if (query.equals("Attenzione ci sono aggiornamenti dal sito di MIPAAF")) { // && oraAttuale >= l2 &&
																							// oraAttuale <= l1
					SendMessage message = new SendMessage().setChatId((long) 145645559).setText(query + "\n"
							+ " Ultima modifica rilevata : Mon Oct 15 12:59:16 CEST 2018" + new java.util.Date());
					try {
						mySianConnect.execute(message);
					} catch (TelegramApiException e) {
						e.printStackTrace();
					}
					scheduler.shutdown();
				} else if (true) { // qui a posto di firstTime ci va una query al db, e poi va aggiornato il campo
									// in true
					firstTime = false;
					SendMessage message = new SendMessage().setChatId(update.getMessage().getChatId()).setText(query);
					try {
						mySianConnect.execute(message);
					} catch (TelegramApiException e) {
						e.printStackTrace();
					}
				}

			}
		};

		// scheduler.schedule(task, 1, TimeUnit.MINUTES);
		scheduler.scheduleWithFixedDelay(task, 0, 20, TimeUnit.MINUTES);

	}
}