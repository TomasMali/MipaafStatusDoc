package Jsoup;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Date;

public class Query {

	public static String guida = "";
	public static String regoleTecniche = "";
	public static String ultimaModificaRegoleTechnicheWebServices = "Mon Oct 15 12:59:16 CEST 2018";
	public static String ultimaModificaCodificheRegistriVitivinicoli = "Mon Oct 15 12:59:16 CEST 2018";

	public static final String tecnicheWebService = "https://www.sian.it/public/mipaaf/WS%20MVV-E%20vers%201.6.zip";
	public static final String codificheRegistriVitivinicoli = "http://www.sian.it/public/mipaaf/Codifiche_registro_vitivinicolo_v7%20(S-MIP-MRGA-K3-15004).pdf";

	/**
	 * Decide qual'è il link da far partire il thread
	 * 
	 * @return
	 * @throws Exception
	 */
	public static String copyURLToFile(String url_) {

		switch (url_) {
		case tecnicheWebService:
			return TecnicheWebService();
		case codificheRegistriVitivinicoli:
			return CodificheRegistriVitivinicoli();
		default:
			break;
		}
		return "URL del sito non Esistente! *Non dovrebbe verificarsi*";

	}

	/**
	 * Effettua una connessione al server della pagina web per controllare lo stato dell'ultima modifica del link
	 * TecnicheWebService
	 * 
	 * @return
	 */
	public static String TecnicheWebService() {
		try {
			URL url = new URL(tecnicheWebService);
			System.out.println("TEST : " + new Date(url.openConnection().getLastModified()).toString());

			@SuppressWarnings("unused")
			InputStream input = url.openStream();

			if (ultimaModificaRegoleTechnicheWebServices.equals(new Date(url.openConnection().getLastModified())
					.toString())) {
				return "Non ci sono Aggiornamenti dal sito di MIPAAF";
			} else
				throw new IOException();

		} catch (IOException ioEx) {
			return "Attenzione ci sono aggiornamenti dal sito di MIPAAF";
		}
	}

	/**
	 * Effettua una connessione al server della pagina web per controllare lo stato dell'ultima modifica del link
	 * CodificheRegistriVitivinicoli
	 * 
	 * @return
	 */
	public static String CodificheRegistriVitivinicoli() {
		try {
			URL url = new URL(codificheRegistriVitivinicoli);
			System.out.println("TEST : " + new Date(url.openConnection().getLastModified()).toString());

			@SuppressWarnings("unused")
			InputStream input = url.openStream();

			if (ultimaModificaRegoleTechnicheWebServices.equals(new Date(url.openConnection().getLastModified())
					.toString())) {
				return "Non ci sono Aggiornamenti dal sito di MIPAAF";
			} else
				throw new IOException();

		} catch (IOException ioEx) {
			return "Attenzione ci sono aggiornamenti dal sito di MIPAAF";
		}
	}

}
