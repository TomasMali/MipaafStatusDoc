package DAO;

import java.util.Date;
import java.util.List;

public class Tests {

	public static void main(String[] args) {

		List<Abilitazione> users = Queries.GetUserIdWithProjectAndDescription("Sian", "SianConnect");

		Queries.UpdateTimestampLinks(1, new Date(System.currentTimeMillis()).toString());

		System.out.println(new Date(System.currentTimeMillis()).toString());
		System.out.println(users);

	}

}
