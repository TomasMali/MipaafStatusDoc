package Jsoup;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Date;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Query {

	public static String guida = "";
	public static String regoleTecniche = "";
	public static String ultimaModifica = "Mon Oct 15 12:59:16 CEST 2018";

	public static String getSian() throws IOException {
		Document doc = Jsoup.connect(
				"https://mipaaf.sian.it/portale-mipaaf/scarico.jsp?op=14&referer=https%3A%2F%2Fwww.sian.it%2Fportale-mipaaf%2Fhome.jsp")
				.get();

		Elements elements = doc.select("ul.elenco-servizi li");

		String query = "";
		if (guida.isEmpty())
			guida = elements.get(0).select("a").text();
		if (regoleTecniche.isEmpty())
			regoleTecniche = elements.get(1).select("a").text();

		String guida_new = elements.get(0).select("a").text();
		String regoleTecniche_new = elements.get(1).select("a").text();

		if (!guida.equals(guida_new)) {
			query = query + "E' stato aggiornato: " + guida_new + "\n";
			guida = guida_new;
		}
		if (!regoleTecniche.equals(regoleTecniche_new)) {
			query = query + "E' stato aggiornato: " + regoleTecniche_new + "\n";
			regoleTecniche = regoleTecniche_new;
		}
		System.out.println(new java.util.Date().getTime());
		System.out.println(elements.get(0).select("a").text());
		System.out.println(elements.get(1).select("a").text());

		return guida_new.equals(guida) && regoleTecniche_new.equals(regoleTecniche)
				? "Non ci sono Aggiornamenti dal sito di MIPAAF"
				: query;

	}

	public static String copyURLToFile() {
		String sUrl = "https://www.sian.it/public/mipaaf/WS%20MVV-E%20vers%201.6.zip";

		try {

			// URL url2 = Test.class.getResource("https://www.sian.it/public/mipaaf/WS%20MVV-E%20vers%201.6.zip");
			// System.out.println("TEST : " + new Date(url2.openConnection().getLastModified()));

			URL url = new URL(sUrl);
			System.out.println("TEST : " + new Date(url.openConnection().getLastModified()).toString());

			InputStream input = url.openStream();

			if (ultimaModifica.equals(new Date(url.openConnection().getLastModified()).toString())) {
				return "Non ci sono Aggiornamenti dal sito di MIPAAF";
			} else

				throw new IOException();

		} catch (IOException ioEx) {

			return "Attenzione ci sono aggiornamenti dal sito di MIPAAF";
		}
	}

}
