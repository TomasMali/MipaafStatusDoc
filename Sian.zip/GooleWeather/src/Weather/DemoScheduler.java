package Weather;

import java.io.IOException;
import java.sql.Time;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.telegram.telegrambots.api.methods.send.SendMessage;
import org.telegram.telegrambots.api.objects.Update;
import org.telegram.telegrambots.exceptions.TelegramApiException;

import Jsoup.Query;

/**
 * This is a sample class to execute scheduler on specific date based on <code>java.util.Calendar</code>. Over here,
 * <code>executor</code> is a runnable which run on everyday basis from 8:00 AM to 5:00 PM.
 * 
 * @author Chintan Patel
 */
public class DemoScheduler {

	public static MyWeather myWeather = null;
	public static Update update = null;
	public static String query = "";
	public static boolean firstTime = true;
	public static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

	DemoScheduler(MyWeather instance, Update update) {
		myWeather = instance;
		this.update = update;

	}

	public static void setQuery(String s) {
		query = s;
	}

	public static void getTask() throws IOException {

		Runnable task = new Runnable() {

			@Override
			public void run() {

				String query = Query.copyURLToFile();
				System.out.println(new java.util.Date() + "\n" + query);
				Time t1 = Time.valueOf("21:00:00");
				long l1 = t1.getTime();
				Time t2 = Time.valueOf("08:00:00");
				long l2 = t2.getTime();
				long oraAttuale = new java.util.Date().getTime();
				if (query.equals("Attenzione ci sono aggiornamenti dal sito di MIPAAF")) { // && oraAttuale >= l2 &&
																							// oraAttuale <= l1
					SendMessage message = new SendMessage().setChatId(update.getMessage().getChatId()).setText(query
							+ "\n" + " Ultima modifica: " + oraAttuale);
					try {
						myWeather.execute(message);
					} catch (TelegramApiException e) {
						e.printStackTrace();
					}
					scheduler.shutdown();
				} else if (firstTime) {
					firstTime = false;
					SendMessage message = new SendMessage().setChatId(update.getMessage().getChatId()).setText(query);
					try {
						myWeather.execute(message);
					} catch (TelegramApiException e) {
						e.printStackTrace();
					}
				}

			}
		};

		// scheduler.schedule(task, 1, TimeUnit.MINUTES);
		scheduler.scheduleWithFixedDelay(task, 0, 20, TimeUnit.MINUTES);

	}
}