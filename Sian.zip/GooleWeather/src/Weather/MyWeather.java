package Weather;

import java.io.IOException;

import org.telegram.telegrambots.api.methods.send.SendMessage;
import org.telegram.telegrambots.api.objects.Update;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.exceptions.TelegramApiException;

public class MyWeather extends TelegramLongPollingBot {

	boolean partito = false;

	@Override
	public String getBotToken() {
		return "645382473:AAG1Vtkoky27VLINnIWRvaxQxqig-xsbKa4";
	}

	public String getBotUsername() {
		return "siandocstatus";
		// tomasmalibot
		// 502596920:AAGXj1omTxPldCElns1Wiw965LqslMSKBHw
		// TomasSubitoBot
		// 657809545:AAEA4xHiTKLndDuRJc9G5XYrwt-ul2WFqH0
		// tomasweather
		// 601333146:AAHJ4Fa1wDt5x5Tsm2bB7CQE1qhYAEXxyBM
		// siandocstatus
		// 645382473:AAG1Vtkoky27VLINnIWRvaxQxqig-xsbKa4

	}

	@Override
	public void onUpdateReceived(Update update) {

		if (update.hasMessage())
			hasMessage(update);
		else if (update.hasCallbackQuery())
			HasCallbackQuery(update);

	}

	public void hasMessage(Update update) {

		if (update.getMessage().hasText()) {
			if (update.getMessage().getText().toUpperCase().equals("SIAN")) {
				if (partito == true) {
					SendMessage message = new SendMessage().setChatId(update.getMessage().getChatId()).setText(
							"Hai attivato già le notifiche per MIPAAF");
					try {
						execute(message);
					} catch (TelegramApiException e) {
						e.printStackTrace();
					}
					return;
				}

				DemoScheduler demo = new DemoScheduler(this, update);
				try {
					demo.getTask();
				} catch (IOException e) {
					e.printStackTrace();
				}

				SendMessage message = new SendMessage().setChatId(update.getMessage().getChatId()).setText(
						"Da questo momento riceverai un messaggio quando MIPAAF viene aggiornato");
				try {
					partito = true;
					execute(message);
				} catch (TelegramApiException e) {
					e.printStackTrace();
				}

			} else {
				SendMessage message = new SendMessage().setChatId(update.getMessage().getChatId()).setText(
						"Scrivi 'Sian' per monitorare il sito");
				try {
					execute(message);
				} catch (TelegramApiException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void HasCallbackQuery(Update update) {

	}

}
